let farmer;
let foods = [];
let pollutants = [];
let score = 0;
let gameOver = false;
let cityProgress = 0;
let maxProgress = 10;
let gameState = "intro"; // intro, playing, gameover, victory
let market;

function setup() {
  createCanvas(600, 800);
  farmer = new Farmer();
  market = new Market();
  textFont('Arial');
}

function draw() {
  background(220);
  
  if (gameState === "intro") {
    showIntroScreen();
  } 
  else if (gameState === "playing") {
    drawGame();
  } 
  else {
    showEndScreen();
  }
}

function drawGame() {
  // Fundo dividido
  drawBackground();
  
  // Elementos do jogo
  farmer.show();
  farmer.move();
  market.show();

  // Geração de itens
  if (frameCount % 60 === 0 && random() > 0.3) {
    foods.push(new FoodItem(random(20, width-20), -20, 'tomato'));
  }
  
  if (frameCount % 90 === 0) {
    pollutants.push(new Pollutant(random(20, width-20), height+20, random(['trash', 'smoke'])));
  }

  // Atualização de itens
  updateItems();
  
  // HUD
  displayHUD();
}

function showIntroScreen() {
  fill(144, 238, 144);
  rect(0, 0, width, height);
  
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(32);
  text("COLHEITA & CONEXÃO", width/2, 100);
  
  textSize(20);
  text("Você é um fazendeiro que precisa", width/2, 200);
  text("abastecer o mercado da cidade", width/2, 230);
  text("com tomates frescos!", width/2, 260);
  
  // Instruções
  textSize(18);
  text("→ Use as SETAS para mover o fazendeiro", width/2, 350);
  text("→ Colete os TOMATES que caem do campo", width/2, 380);
  text("→ Evite o LIXO que vem da cidade", width/2, 410);
  text("→ Abasteça o MERCADO para a grande festa!", width/2, 440);
  
  // Botão de iniciar
  fill(50, 205, 50);
  rect(width/2-100, 550, 200, 50, 10);
  fill(255);
  text("COMEÇAR (ESPAÇO)", width/2, 575);
}

function drawBackground() {
  // Campo (parte de baixo)
  fill(144, 238, 144);
  rect(0, height/2, width, height/2);
  
  // Cidade (parte de cima)
  fill(169, 169, 169);
  rect(0, 0, width, height/2);
  
  // Ponte
  fill(139, 69, 19);
  rect(width/2-50, height/2-10, 100, 20);
}

function updateItems() {
  // Tomates
  for (let i = foods.length-1; i >= 0; i--) {
    foods[i].update();
    foods[i].show();
    
    if (foods[i].hits(farmer)) {
      score += 5;
      foods.splice(i, 1);
    } else if (foods[i].offscreen()) {
      foods.splice(i, 1);
    }
    
    // Entrega no mercado
    if (foods[i] && foods[i].hits(market)) {
      cityProgress++;
      foods.splice(i, 1);
    }
  }
  
  // Poluentes
  for (let i = pollutants.length-1; i >= 0; i--) {
    pollutants[i].update();
    pollutants[i].show();
    
    if (pollutants[i].hits(farmer)) {
      score = max(0, score-3);
      pollutants.splice(i, 1);
    } else if (pollutants[i].offscreen()) {
      pollutants.splice(i, 1);
    }
  }
  
  // Vitória
  if (cityProgress >= maxProgress) {
    gameState = "victory";
  }
}

function displayHUD() {
  fill(0);
  textSize(24);
  text(`Tomates: ${score}`, 20, 30);
  text(`Mercado: ${cityProgress}/${maxProgress}`, 20, 60);
  
  // Barra de progresso
  fill(200);
  rect(width-220, 20, 200, 20);
  fill(0, 200, 0);
  rect(width-220, 20, 200 * (cityProgress/maxProgress), 20);
}

function showEndScreen() {
  fill(0, 100);
  rect(0, 0, width, height);
  
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(40);
  text(gameState === "victory" ? "FESTA DA COLHEITA!" : "FIM DE JOGO", width/2, height/2-50);
  
  textSize(24);
  text(`Tomates coletados: ${score}`, width/2, height/2);
  text(`Mercado abastecido: ${cityProgress}/${maxProgress}`, width/2, height/2+40);
  
  textSize(18);
  text("Pressione R para recomeçar", width/2, height/2+100);
}

function keyPressed() {
  if (gameState === "intro" && key === ' ') {
    gameState = "playing";
    return;
  }
  
  if (keyCode === LEFT_ARROW) farmer.setDir(-1);
  else if (keyCode === RIGHT_ARROW) farmer.setDir(1);
  else if (key === 'r' || key === 'R') resetGame();
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) farmer.setDir(0);
}

function resetGame() {
  score = 0;
  cityProgress = 0;
  gameState = "playing";
  foods = [];
  pollutants = [];
  farmer = new Farmer();
}

// Classes do jogo
class Farmer {
  constructor() {
    this.x = width/2;
    this.y = height-100;
    this.size = 50;
    this.dir = 0;
  }

  show() {
    // Caminhão do fazendeiro
    fill(255, 215, 0);
    rect(this.x, this.y, this.size+20, this.size-10);
    fill(70);
    rect(this.x+10, this.y-15, this.size, 15);
  }

  move() {
    this.x += this.dir * 6;
    this.x = constrain(this.x, 0, width-this.size-20);
  }

  setDir(dir) {
    this.dir = dir;
  }
}

class Market {
  constructor() {
    this.x = width/2;
    this.y = height/2-50;
    this.size = 80;
  }

  show() {
    // Mercado
    fill(255, 0, 0);
    rect(this.x-this.size/2, this.y, this.size, this.size/2);
    fill(255);
    textSize(16);
    text("MERCADO", this.x, this.y+30);
  }
}

class FoodItem {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.size = 25;
    this.speed = 3;
  }

  update() {
    this.y += this.speed;
  }

  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size);
    // Cabinho do tomate
    fill(0, 100, 0);
    rect(this.x-2, this.y-this.size/2, 4, 5);
  }

  hits(obj) {
    return dist(this.x, this.y, obj.x + obj.size/2, obj.y + obj.size/2) < this.size + obj.size/2;
  }

  offscreen() {
    return this.y > height;
  }
}

class Pollutant {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.size = 30;
    this.speed = 4;
  }

  update() {
    this.y -= this.speed;
  }

  show() {
    if (this.type === 'trash') {
      fill(100);
      rect(this.x, this.y, this.size, this.size, 2);
    } else {
      fill(150, 150, 150, 200);
      ellipse(this.x, this.y, this.size);
    }
  }

  hits(farmer) {
    return dist(this.x, this.y, farmer.x + farmer.size/2, farmer.y + farmer.size/2) < this.size + farmer.size/2;
  }

  offscreen() {
    return this.y < 0;
  }
}